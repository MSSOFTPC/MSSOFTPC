// login
$('#LoginFrom').submit(function (e) { 
    e.preventDefault();
    alert('samar')
    
});


// forget

// forget token