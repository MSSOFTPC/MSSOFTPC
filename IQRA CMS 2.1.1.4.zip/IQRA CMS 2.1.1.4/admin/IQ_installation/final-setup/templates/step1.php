<div class="container mt-4 align-center">
<div class="card-col-9">
    <div class="wizard-image m-auto text-center">
            <img src="<?php echo IQ_data('logo');?>" width="150px" >
    </div>
<div class="card notification-card border-0 shadow IQ_admin_card" id="IQ_dashbaord_welcome">
    <!-- body -->
        <div class="card-body m-4">

            
            <div class="row">
                <?php 
                ?>
              
              <img src="<?php echo IQ_base_url().'admin/IQ_installation/final-setup/templates/' ?>database-uploading.gif" >

              <a href="<?php echo IQ_base_url().'admin?step=2' ?>" class="btn btn-primary">Start Database Migration</a>

            </div>

        </div>
 

        <!-- end body -->



    </div>
    
    </div>

    </div>