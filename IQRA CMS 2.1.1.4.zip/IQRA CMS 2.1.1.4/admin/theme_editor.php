
<?php include('include.php');
head('IQ Theme Editor');
loginonly('');

?>        

<?php get_sidebar(); ?>
        <main class="content">
<?php get_header(); ?>

<!-- main body start -->
        <h1 class="text-center title" style="margin: 100px 0">Theme Editor (Coming Soon)</h1>

      
	
<?php footer(); ?>

