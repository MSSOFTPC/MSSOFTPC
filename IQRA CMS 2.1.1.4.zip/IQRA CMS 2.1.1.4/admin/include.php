<?php 

include('function.php');
include('functions/action_view_function_global.php');
include('includes/head.php');
include('includes/footer.php');
include('includes/header.php');
include('includes/sidebar.php');
include('modules/widget.php');
include('core/addons-controller.php');
include('core/themes-controller.php');

// modules
include('modules/dashboardbreadcrumb.php');

// IQ installation
include('IQ_installation/htaccess-generator.php');


?>
