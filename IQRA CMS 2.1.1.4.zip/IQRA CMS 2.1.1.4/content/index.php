<?php
// Silent is Goldedn